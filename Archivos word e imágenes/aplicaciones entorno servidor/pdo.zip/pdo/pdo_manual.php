<?php

echo '<p><strong>PDO::getAvailableDrivers()</strong>';
 print_r(PDO::getAvailableDrivers());
 echo '</p>';
?>