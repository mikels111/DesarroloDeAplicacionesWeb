<?php
$dbname='IFCD0210';
$usuario='usuario1';
$clave='usuario1';
$mbd = new PDO('mysql:host=localhost;dbname='.$dbname, $usuario, $clave);
?>