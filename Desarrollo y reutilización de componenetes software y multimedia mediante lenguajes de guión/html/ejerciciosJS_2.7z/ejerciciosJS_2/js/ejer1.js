
var num = "";
for (let i = 0; i <= 100; i=i+5) {
    num = num + i + "<br>";
}
document.getElementById("p1").innerHTML = num;