let nomb=window.prompt("Escribe tu nombre");
let lugar=window.prompt("Escribe el lugar donde vives");

document.getElementById("texto").innerHTML=`Hola te llamas ${nomb} y vives en ${lugar}`;