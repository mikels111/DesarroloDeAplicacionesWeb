//document.getElementById("bombilla").style.width = ;
function EncenderApagar() {
    let ruta;
    let imagen = document.getElementById("bombilla").getAttribute("src");
    if (imagen == "bombilla-off.gif") {
        ruta = "bombilla-on.gif";
    } else {
        ruta = "bombilla-off.gif";
    }
    document.getElementById("bombilla").src = ruta;
}

function Encender(){
    document.getElementById("bombilla").src = "bombilla-on.gif";
}

function Apagar(){
    document.getElementById("bombilla").src = "bombilla-off.gif";
}