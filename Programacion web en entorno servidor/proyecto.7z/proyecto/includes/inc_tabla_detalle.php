<table id="tabla-detalle" class="ms-table-detalle">
    <tr>
        <th>Detalles</th>
    </tr>
    <tr>
        <td><?php echo "<strong>Título original:</strong> " . $titulo_original ?></td>
    </tr>
    <tr>
        <td><?php echo "<strong>Actores: </strong>" . $actores ?></td>
    </tr>
    <tr>
        <td><?php echo "<strong>Director:</strong> ".$director ?></td>
    </tr>
    <tr>
        <td><?php echo "<strong>Clasificacion:</strong> " . $clasificacion ?></td>
    </tr>
    <tr>
        <td><?php echo "<strong>Duración:</strong> " . $duracion ?></td>
    </tr>
    <tr>
        <td><?php echo "<strong>Genero:</strong> " . $genero ?></td>
    </tr>
    <tr>
        <td><?php echo "<strong>Fecha de estreno:</strong> " . $fecha_estreno  ?></td>
    </tr>
</table>

<!-- <tr>
      <th scope="row">1</th>
    </tr>
    <tr>
      <th scope="row">2</th>
    </tr>
    <tr>
      <th scope="row">3</th>
    </tr> -->