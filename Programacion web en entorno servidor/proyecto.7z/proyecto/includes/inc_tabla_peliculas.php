<table class="table">
  <thead>
    <tr>
      <th scope="col">Título</th>
      <th scope="col">Genero</th>
      <th scope="col">Clasificación</th>
      <th scope="col">Duración</th>
      <th scope="col">Fecha estreno</th>
      <th scope="col">Estatus</th>
      <th scope="col">Opciones</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Titulo</th>
      <td>Genero</td>
      <td>Clasificación</td>
      <td>Duración</td>
      <td>Fecha estreno</td>
      <td>Estatus</td>
      <td>Opciones</td>
    </tr>
  </tbody>
</table>