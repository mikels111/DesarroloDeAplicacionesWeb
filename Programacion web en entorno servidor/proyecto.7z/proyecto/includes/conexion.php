<?php
$servername = "localhost";
$username = "usuario1";
$passw = "usuario1";
$dbname = "Mikels";

// Create connection
$conn = mysqli_connect($servername, $username, $passw, $dbname);
