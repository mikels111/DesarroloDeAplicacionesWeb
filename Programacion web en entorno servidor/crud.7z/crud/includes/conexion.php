<?php
$dbname = 'Mikels';
$usuario = 'usuario1';
$clave = 'usuario1';
$db = new PDO('mysql:host=localhost;dbname=' . $dbname, $usuario, $clave);
?>