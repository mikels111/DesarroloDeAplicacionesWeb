<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <div id="cabecera" style="background:lightblue;">
        <img id="logo" src="img/logo.png" alt="logo">
        <div id="div_navegador">
            <div><a id="inicio" href="index.php">Inicio</a></div>
            <div><a id="info" href="informacion.php">Información</a></div>
            <div><a id="conte" href="contenido.php">Contenido</a></div>
            <div><a id="contacto" href="contacto.php">Contacto</a></div>
        </div>
    </div>
</body>

</html>