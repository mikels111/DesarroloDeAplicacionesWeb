<!DOCTYPE html>
<html lang="es">

<head>
    <?php include("includes/inc_config.php"); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <?php include("includes/inc_cabecera.php"); ?>
    <main>
        <h1>contenido</h1>
        <img class="img_contenido" src="img/donosti1.png" alt="donosti1">
        <img class="img_contenido" src="img/donosti2.png" alt="donosti1">
        <img class="img_contenido" src="img/donosti3.png" alt="donosti1">
        <img class="img_contenido" src="img/pasta.jpg" alt="donosti1">

    </main>

    <?php include("includes/inc_pie.php"); ?>
</body>

</html>