<header>
    <div id="cabecera">
        <img id="logo" src="img/logo.png" alt="logo">
        <nav id="div_navegador">
            <a id="inicio" href="index.php">Inicio</a>
            <a id="info" href="informacion.php">Información</a>
            <a id="conte" href="contenido.php">Contenido</a>
            <a id="contacto" href="contacto.php">Contacto</a>
            </ul>
        </nav>
    </div>
</header>