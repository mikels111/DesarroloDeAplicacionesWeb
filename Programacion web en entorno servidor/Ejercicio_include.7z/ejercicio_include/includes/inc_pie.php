<footer>
    <div id="div_pie">
        <p>Mikel Seara</p>
    </div>
</footer>